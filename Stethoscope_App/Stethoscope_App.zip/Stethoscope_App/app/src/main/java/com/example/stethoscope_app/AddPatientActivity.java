package com.example.stethoscope_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class AddPatientActivity extends AppCompatActivity {
    // Defining keys for intent extras

    public static final String EXTRA_NAME = "com.example.stethoscope_app.name";
    public static final String EXTRA_AGE = "com.example.stethoscope_app.age";
    public static final String EXTRA_BLOOD = "com.example.stethoscope_app.blood";
    public static final String EXTRA_DATE = "com.example.stethoscope_app.date";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_patient);
    }

    public void saveDetails(View view){
        Intent intent = new Intent(this, PatientListActivity.class);
        // Creating Edit Text widgets out of views
        EditText editTextName = (EditText) findViewById(R.id.editTextName);
        EditText editTextAge = (EditText) findViewById(R.id.editTextAge);
        EditText editTextBlood = (EditText) findViewById(R.id.editTextBlood);
        EditText editTextDate = (EditText) findViewById(R.id.editTextDate);
        // Converting input text into strings
        String name = editTextName.getText().toString();
        String age = editTextAge.getText().toString();
        String blood = editTextBlood.getText().toString();
        String date = editTextDate.getText().toString();
        // Creating extras
        intent.putExtra(EXTRA_NAME,name);
        intent.putExtra(EXTRA_AGE,age);
        intent.putExtra(EXTRA_BLOOD,blood);
        intent.putExtra(EXTRA_DATE,date);
        startActivity(intent);
    }
}
