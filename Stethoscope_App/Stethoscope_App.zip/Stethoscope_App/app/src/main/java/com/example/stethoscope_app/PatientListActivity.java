package com.example.stethoscope_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class PatientListActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_list);
        // defining widget as a recycler
        recyclerView = (RecyclerView) findViewById(R.id.patient_recycler_view);

        // improves performance when we know the content does not change layout size of the recycler
        recyclerView.setHasFixedSize(true);

        // linear layout manager
        // allows the recyclerview to fill itself with views in a certain format e.g. list vs grid

        // defining layout as linear
        layoutManager = new LinearLayoutManager(this);
        // assigning this layout to our recyclerView
        recyclerView.setLayoutManager(layoutManager);

        // specify an adapter
        // adapters manager the view holder objects, creating view holders as needed
        // also binds view holders to their data
        mAdapter = new MyAdapter(myDataset);
        recyclerView.setAdapter(mAdapter);

    }

    public void addPatient(View view) {
        Intent intent = new Intent(this, AddPatientActivity.class);
        startActivity(intent);
    }


    // creates views for items, and replaces the content of some of the views with new data items
    // when the original item is no longer visible
    // below implements a data set that consists of array of strings displayed using TextView widgets
    public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
        // defining array that will hold data set
        private String[] mDataset;
        // View holders are in charge of displaying a single item with a view
        // e,g, view holder might represent a single album

        // Here we are providing a reference to the views for each data item
        // Complex data items may need more than one view per item, and
        // you provide access to all the views for a data item in a view holder

        public static class MyViewHolder extends RecyclerView.Viewholder{
            // here each data item is just a string
            public TextView textView;
            public MyViewHolder(TextView v){
                // calls superclass methods and to access the superclass constructor
                super(v);
                textView = v;
            }
        }
        // constructor
        public MyAdapter(String[] myDataset) {
            mDataset = myDataset;
        }
        public MyAdapter.MyViewholder onCreateViewHolder(ViewGroup parent, int viewType){
            // Creating a new view
            TextView v = (TextView) LayoutInflater.from(parent.getContext()).inflate(R.layout.my_text_view, parent, false);
            MyViewHolder vh = new MyViewHolder(v);
            return vh;
        }

        // Replacing contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(MyViewHolder holder, int position){
            // get element from your dataset at this position
            // replace the contents of the vie with that element
            holder.textView.setText(mDataset[position]);
        }
        // Return the size of your dataset (invoked by the layout manager)
        @Override
        public int getItemCount(){
            return mDataset.length;
        }
    }
}


